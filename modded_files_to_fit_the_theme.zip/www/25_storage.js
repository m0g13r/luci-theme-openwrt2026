'use strict';
'require baseclass';
'require rpc';
'require fs';

#modded to show smart status

var callSystemInfo = rpc.declare({ object: 'system', method: 'info' });
var callMountPoints = rpc.declare({ object: 'luci', method: 'getMountPoints', expect: { result: [] } });
var MountSkipList = ["/rom", "/tmp", "/dev", "/overlay", "/", ];

function progressbar(value, max, byte) {
    var vn = parseInt(value) || 0,
        mn = parseInt(max) || 100,
        fv = byte ? String.format('%1024.2mB', value) : value,
        fm = byte ? String.format('%1024.2mB', max) : max,
        pc = Math.floor((100 / mn) * vn);
    return E('div', {
        'class': 'cbi-progressbar',
        'title': '%s / %s (%d%%)'.format(fv, fm, pc)
    }, E('div', {
        'style': 'width:%.2f%%'.format(pc)
    }));
}

return baseclass.extend({
    title: _('Storage'),
    load: function() {
        return Promise.all([
            L.resolveDefault(callSystemInfo(), {}),
            L.resolveDefault(callMountPoints(), {}),
            L.resolveDefault(fs.exec("/bin/sh", ["-c", "for d in /dev/sd[a-z]; do smartctl -q silent -a $d; c=$?; if [ $((c & 24)) -ne 0 ]; then echo \"$d:FAILED\"; elif [ $((c & 224)) -ne 0 ]; then echo \"$d:WARNING\"; elif [ $((c & 7)) -ne 0 ]; then echo \"$d:UNKNOWN\"; else echo \"$d:PASSED\"; fi; done"]), {stdout: ''})
        ]);
    },
    render: function(data) {
        var systeminfo = data[0],
            mounts = data[1],
            smartData = data[2],
            root = L.isObject(systeminfo.root) ? systeminfo.root : {},
            tmp = L.isObject(systeminfo.tmp) ? systeminfo.tmp : {};

        var smartInfo = {};
        if (smartData && smartData.stdout) {
            var smartLines = smartData.stdout.trim().split('\n');
            for (var j = 0; j < smartLines.length; j++) {
                var parts = smartLines[j].split(':');
                if (parts.length >= 2) {
                    smartInfo[parts[0]] = parts[1].trim();
                }
            }
        }

        const existenceChk = function(fields, name, values) {
            if (!fields.hasOwnProperty(name)) fields[name] = values;
        };

        var fields = {};
        existenceChk(fields, _('Disk space'), { used: root.used * 1024, size: root.total * 1024 });
        existenceChk(fields, _('Temp space'), { used: tmp.used * 1024, size: tmp.total * 1024 });

        for (var i = 0; i < mounts.length; i++) {
            var entry = mounts[i];
            if (MountSkipList.includes(entry.mount)) continue;
            var name = entry.device + ' (' + entry.mount + ')',
                used = entry.size - entry.free;
            existenceChk(fields, name, { used: used, size: entry.size, device: entry.device });
        }

        var table = E('table', { 'class': 'table' });
        Object.keys(fields).forEach(function(key) {
            var device = fields[key].device;
            
            var content = [
                E('span', { 'style': 'vertical-align: middle;' }, [key])
            ];

            if (device && device.indexOf('/dev/sd') === 0) {
                var baseDev = device.replace(/[0-9]+$/, '');
                var status = smartInfo[baseDev];
                
                if (status) {
                    var dotColor = '#6c757d'; 
                    if (status === 'PASSED' || status === 'OK') {
                        dotColor = '#28a745'; 
                    } else if (status === 'WARNING') {
                        dotColor = '#ffc107'; 
                    } else if (status === 'FAILED' || status === 'ERROR') {
                        dotColor = '#dc3545'; 
                    }
                    
                    var dot = E('span', {
                        'style': 'display:inline-block; width:12px; height:12px; border-radius:50%; background-color:' + dotColor + '; margin-left: 8px; vertical-align: middle;',
                        'title': 'SMART Status: ' + status
                    });

                    var smartLabel = E('span', {
                        'style': 'margin-left: 6px; font-size: 10px; font-weight: bold; color: #555; background-color: #e9ecef; border: 1px solid #ced4da; border-radius: 10px; padding: 1px 6px; vertical-align: middle;'
                    }, ['SMART']);
                    
                    content.push(dot, smartLabel);
                }
            }

            table.appendChild(E('tr', { 'class': 'tr' }, [
                E('td', { 'class': 'td left', 'width': '33%', 'style': 'vertical-align: middle;' }, content),
                E('td', { 'class': 'td left', 'style': 'vertical-align: middle;' }, [
                    (fields[key].used != null) ? progressbar(fields[key].used, fields[key].size, true) : '?'
                ])
            ]));
        });
        
        return table;
    }
});
